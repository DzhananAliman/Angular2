import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class RecordService {

  constructor(private http: HttpClient) { }

  getAll() {
    return this.http.get(`${environment.apiUrl}/records`);
  }

  getOne(id: string) {
    return this.http.get(`${environment.apiUrl}/records/${id}`);
  }

  create(record: any) {
    return this.http.post(`${environment.apiUrl}/records`, record);
  }

  update(id: string, record: any) {
    return this.http.put(`${environment.apiUrl}/records/${id}`, record);
  }

  delete(id: string) {
    return this.http.delete(`${environment.apiUrl}/records/${id}`);
  }
}

