import { Routes } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { CatalogComponent } from './components/catalog/catalog.component';
import { CreateRecordComponent } from './components/create-record/create-record.component';
import { DetailsComponent } from './components/details/details.component';
import { EditRecordComponent } from './components/edit-record/edit-record.component';
import { LoginComponent } from './components/login/login.component';
import { ProfileComponent } from './components/profile/profile.component';
import { RegisterComponent } from './components/register/register.component';
import { AuthGuard } from './guards/auth.guard';

export const routes: Routes = [
  // Публични
  { path: '', component: HomeComponent },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },

  // Защитени (само логнати)
  { path: 'catalog', component: CatalogComponent, canActivate: [AuthGuard] },
  { path: 'create', component: CreateRecordComponent, canActivate: [AuthGuard] },
  { path: 'details/:id', component: DetailsComponent, canActivate: [AuthGuard] },
  { path: 'edit/:id', component: EditRecordComponent, canActivate: [AuthGuard] },
  { path: 'profile', component: ProfileComponent, canActivate: [AuthGuard] },

  // fallback
  { path: '**', redirectTo: '' }
];


