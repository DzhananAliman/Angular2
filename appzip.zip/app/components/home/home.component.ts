import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  standalone: true,
  templateUrl: './home.component.html',   // файлът с HTML шаблона
  styleUrls: ['./home.component.css']     // файлът с CSS стиловете
})
export class HomeComponent {
  goTo(page: string) {
    alert('Clicked on: ' + page);
    // Тук можеш да добавиш логика за смяна на съдържанието
  }
}

