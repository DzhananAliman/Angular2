import { Component } from '@angular/core';

@Component({
  selector: 'app-create-record',
  standalone: true,
  imports: [],
  templateUrl: './create-record.component.html',
  styleUrl: './create-record.component.css'
})
export class CreateRecordComponent {

}
